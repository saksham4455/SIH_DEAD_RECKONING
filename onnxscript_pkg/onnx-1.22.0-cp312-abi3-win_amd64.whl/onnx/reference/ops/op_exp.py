# Copyright (c) ONNX Project Contributors

# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import numpy as np

from onnx.reference.ops._op import OpRunUnaryNum


class Exp(OpRunUnaryNum):
    def _run(self, x):
        return (np.exp(x).astype(x.dtype),)
